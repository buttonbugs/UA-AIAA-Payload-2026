%TF.GenerationSoftware,KiCad,Pcbnew,9.0.5*%
%TF.CreationDate,2026-04-19T15:40:25-07:00*%
%TF.ProjectId,Antenna_PCB_v1,416e7465-6e6e-4615-9f50-43425f76312e,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.5) date 2026-04-19 15:40:25*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.140000X-0.140000X-0.170000X0.140000X-0.170000X0.140000X0.170000X-0.140000X0.170000X0*%
%ADD11RoundRect,0.147500X-0.147500X-0.172500X0.147500X-0.172500X0.147500X0.172500X-0.147500X0.172500X0*%
%ADD12R,5.080000X2.290000*%
%ADD13R,5.080000X2.420000*%
G04 APERTURE END LIST*
D10*
%TO.C,C2*%
X120480000Y-104000000D03*
X119520000Y-104000000D03*
%TD*%
D11*
%TO.C,L2*%
X130485000Y-104000000D03*
X129515000Y-104000000D03*
%TD*%
D10*
%TO.C,C1*%
X119520000Y-96000000D03*
X120480000Y-96000000D03*
%TD*%
D12*
%TO.C,J2*%
X146930000Y-100000000D03*
D13*
X146930000Y-104380000D03*
X146930000Y-95620000D03*
%TD*%
D11*
%TO.C,L1*%
X129515000Y-96000000D03*
X130485000Y-96000000D03*
%TD*%
D12*
%TO.C,J1*%
X103070000Y-100000000D03*
D13*
X103070000Y-95620000D03*
X103070000Y-104380000D03*
%TD*%
M02*
